package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import utils.DBUtils;
import utils.SQLQueries;
import vo.MemberRegistrationVO;
import exception.MemberRegistrationBusinessException;
import exception.MemberRegistrationException;

public class MemberRegistrationDAO {

	public void addUserDetails(MemberRegistrationVO vo)
			throws ClassNotFoundException, IOException,
			MemberRegistrationException, MemberRegistrationBusinessException {
		Connection con = null;
		String query = SQLQueries.ADDTEAMMEMBER;
		String query1 = SQLQueries.ADDTEAMMEMBERLOGIN;
		try {
			con = DBUtils.getConnection();
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, vo.getUserId());
			stmt.setString(2, vo.getPassword());
			stmt.setString(3, vo.getName());
			stmt.setString(4, vo.getWorkLocation());
			stmt.setString(5, vo.getContactNumber());
			stmt.setString(6, vo.getEmailId());
			stmt.setString(7, vo.getSecurityQuestion1());
			stmt.setString(8, vo.getSecurityAnswer1());
			stmt.setString(9, vo.getSecurityQuestion2());
			stmt.setString(10, vo.getSecurityAnswer2());
			stmt.setString(11, vo.getSecurityQuestion3());
			stmt.setString(12, vo.getSecurityAnswer3());
			int i = stmt.executeUpdate();
			if (i >= 0) {
				stmt = con.prepareStatement(query1);
				stmt.setString(1, vo.getUserId());
				stmt.setString(2, vo.getPassword());
				stmt.executeUpdate();

			}
		} catch (SQLException e) {
			// throw new MemberRegistrationException(e.getMessage());
			// throw new MemberRegistrationBusinessException(
			// PropertyUtil.getMessage("605"));
			e.printStackTrace();

		}

	}

	public void addMemberDetails(MemberRegistrationVO vo)
			throws ClassNotFoundException, IOException,
			MemberRegistrationException, MemberRegistrationBusinessException {
		Connection con = null;
		String query = SQLQueries.ADDMEMBERDETAILS;
		try {
			con = DBUtils.getConnection();
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, vo.getUserId());
			stmt.setString(2, vo.getPassword());
			stmt.setString(3, vo.getName());
			stmt.setString(4, vo.getWorkLocation());
			stmt.setString(5, vo.getContactNumber());
			stmt.setString(6, vo.getEmailId());
			stmt.setString(7, vo.getSecurityQuestion1());
			stmt.setString(8, vo.getSecurityAnswer1());
			stmt.setString(9, vo.getSecurityQuestion2());
			stmt.setString(10, vo.getSecurityAnswer2());
			stmt.setString(11, vo.getSecurityQuestion3());
			stmt.setString(12, vo.getSecurityAnswer3());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// throw new MemberRegistrationException(e.getMessage());
			// throw new MemberRegistrationBusinessException(
			// PropertyUtil.getMessage("605"));
			e.printStackTrace();

		}

	}
}
