package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import utils.DBUtils;
import utils.SQLQueries;
import vo.MemberRegistrationVO;
import exception.MemberRegistrationBusinessException;
import exception.MemberRegistrationException;

public class ApproveUsersDAO {
	public static ArrayList<MemberRegistrationVO> userList = new ArrayList<MemberRegistrationVO>();
	Connection con;
	PreparedStatement stmt;

	public void approveUsers() throws ClassNotFoundException, IOException,
			SQLException {
		String query = SQLQueries.GETUSERS;
		con = DBUtils.getConnection();
		stmt = con.prepareStatement(query);
		ResultSet set = stmt.executeQuery();
		while (set.next()) {
			MemberRegistrationVO vo = new MemberRegistrationVO();
			vo.setUserId(set.getString(1));
			vo.setPassword(set.getString(2));
			vo.setName(set.getString(3));
			vo.setWorkLocation(set.getString(4));
			vo.setContactNumber(set.getString(5));
			vo.setEmailId(set.getString(6));
			vo.setSecurityQuestion1(set.getString(7));
			vo.setSecurityAnswer1(set.getString(8));
			vo.setSecurityQuestion2(set.getString(7));
			vo.setSecurityAnswer2(set.getString(8));
			vo.setSecurityQuestion3(set.getString(7));
			vo.setSecurityAnswer3(set.getString(8));
			ApproveUsersDAO.userList.add(vo);
		}

	}

	public void getUsers(String[] val) throws ClassNotFoundException,
			IOException, SQLException, MemberRegistrationException,
			MemberRegistrationBusinessException {
		String query = SQLQueries.GETUSERDETAILS;
		con = DBUtils.getConnection();
		stmt = con.prepareStatement(query);
		for (int i = 0; i < val.length; i++) {
			stmt.setLong(1, Long.parseLong(val[i]));
			ResultSet set = stmt.executeQuery();
			while (set.next()) {
				MemberRegistrationVO vo = new MemberRegistrationVO();
				vo.setUserId(set.getString(1));
				vo.setPassword(set.getString(2));
				vo.setName(set.getString(3));
				vo.setWorkLocation(set.getString(4));
				vo.setContactNumber(set.getString(5));
				vo.setEmailId(set.getString(6));
				vo.setSecurityQuestion1(set.getString(7));
				vo.setSecurityAnswer1(set.getString(8));
				vo.setSecurityQuestion2(set.getString(7));
				vo.setSecurityAnswer2(set.getString(8));
				vo.setSecurityQuestion3(set.getString(7));
				vo.setSecurityAnswer3(set.getString(8));
				MemberRegistrationDAO d = new MemberRegistrationDAO();
				d.addUserDetails(vo);
				deleteApproveUsers(val);
			}

		}
	}

	public void deleteApproveUsers(String[] val) throws ClassNotFoundException,
			IOException, SQLException {
		String query = SQLQueries.DELETEAPPROVEDUSERS;
		con = DBUtils.getConnection();
		stmt = con.prepareStatement(query);
		for (int i = 0; i < val.length; i++) {
			stmt.setLong(1, Long.parseLong(val[i]));
			stmt.executeUpdate();
		}
	}

}
