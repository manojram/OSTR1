package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.jfree.data.jdbc.JDBCCategoryDataset;

import utils.DBUtils;
import utils.SQLQueries;
import vo.GenerateReportVO;
import exception.GenerateReportException;

public class DatabaseChartDAO {
	Connection connection = null;
	JDBCCategoryDataset dataset = null;

	public JDBCCategoryDataset generateGraphAssociateID(long ID)
			throws InstantiationException, IllegalAccessException,
			ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		try {
			connection = DriverManager
					.getConnection("jdbc:mysql://127.0.0.1:3306/ostr_db",
							"root", "password-1");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dataset = new JDBCCategoryDataset(connection);
		try {
			dataset.executeQuery("Select task_id,sum(time_taken) as TIME_TAKEN,sum(estimated_time) AS ESTIMATED_TIME,(estimated_time-time_taken)as DEVIATION from task_details join task_list using(task_id) where userid='"
					+ ID + "' group by task_id");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		return dataset;
	}

	public JDBCCategoryDataset generateGraphTask()
			throws InstantiationException, IllegalAccessException,
			ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		try {
			connection = DriverManager
					.getConnection("jdbc:mysql://127.0.0.1:3306/ostr_db",
							"root", "password-1");
		} catch (SQLException e) {

			e.printStackTrace();
		}
		dataset = new JDBCCategoryDataset(connection);
		try {
			dataset.executeQuery("Select task_id,sum(time_taken) AS TIME_TAKEN,sum(estimated_time) AS ESTIMATED_TIME,(estimated_time-time_taken)as DEVIATION from task_details join task_list using(task_id) group by task_id");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		return dataset;
	}

	public boolean verifyId(GenerateReportVO vo)
			throws GenerateReportException, ClassNotFoundException,
			IOException, SQLException, InstantiationException,
			IllegalAccessException {
		String query = "";
		Connection con = null;
		boolean flag = false;
		try {

			con = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		query = SQLQueries.VERIFYASSOCIATEID;
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setLong(1, vo.getAssociateId());
		ResultSet set = stmt.executeQuery();

		if (set.next()) {
			// COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_NAME,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS,USERID
			flag = true;
		}
		return flag;

	}
}