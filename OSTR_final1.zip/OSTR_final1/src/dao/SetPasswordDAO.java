package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import property.PropertyUtil;
import utils.DBUtils;
import utils.SQLQueries;
import bo.ForgotPasswordBO;
import exception.MemberRegistrationBusinessException;

public class SetPasswordDAO {
	Connection con = null;
	String query = "";
	String question1 = "";
	String answer1 = "";
	String question2 = "";
	String answer2 = "";
	String question3 = "";
	String answer3 = "";

	public void setPassword(String userId)
			throws MemberRegistrationBusinessException {
		try {
			int count = 0;
			con = DBUtils.getConnection();
			query = SQLQueries.GETSECURITYQUESTION;
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, userId);
			ResultSet set = stmt.executeQuery();
			while (set.next()) {
				count++;
				question1 = set.getString(1);
				answer1 = set.getString(2);
				question2 = set.getString(3);
				answer2 = set.getString(4);
				question3 = set.getString(5);
				answer3 = set.getString(6);

			}
			if (count == 0) {
				throw new MemberRegistrationBusinessException(
						PropertyUtil.getMessage("504"));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("504"));
		}
		ForgotPasswordBO.vo.setUserId(userId);
		ForgotPasswordBO.vo.setQuestion1(question1);
		ForgotPasswordBO.vo.setAnswer1(answer1);
		ForgotPasswordBO.vo.setQuestion2(question2);
		ForgotPasswordBO.vo.setAnswer2(answer2);
		ForgotPasswordBO.vo.setQuestion3(question3);
		ForgotPasswordBO.vo.setAnswer3(answer3);

	}
}
