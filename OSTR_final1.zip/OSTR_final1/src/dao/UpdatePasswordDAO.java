package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import utils.DBUtils;
import utils.SQLQueries;
import bo.ForgotPasswordBO;

public class UpdatePasswordDAO {
	Connection con = null;
	String query = "";
	String userId = ForgotPasswordBO.vo.getUserId();
	boolean flag = false;

	public boolean updatePassword(String pwd) throws SQLException {
		try {
			con = DBUtils.getConnection();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		query = SQLQueries.SETPASSWORD;
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, pwd);
		stmt.setString(2, userId);
		if (stmt.executeUpdate() >= 0) {
			flag = true;
			query = SQLQueries.SETLOGINPASSWORD;
			PreparedStatement stmt1 = con.prepareStatement(query);
			stmt1.setString(1, pwd);
			stmt1.setString(2, userId);
			stmt1.executeUpdate();
		}
		return flag;
	}
}
