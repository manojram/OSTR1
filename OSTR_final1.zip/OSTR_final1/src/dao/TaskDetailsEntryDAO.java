package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import utils.DBUtils;
import utils.SQLQueries;
import vo.TaskDetailsEntryVO;
import exception.MemberRegistrationException;
import exception.TaskDetailsBusinessException;

public class TaskDetailsEntryDAO {

	public void updateTaskDetails(TaskDetailsEntryVO vo)
			throws ClassNotFoundException, IOException,
			MemberRegistrationException, TaskDetailsBusinessException {
		Connection con = null;
		String query = SQLQueries.UPDATETASKDETAILS;
		try {
			con = DBUtils.getConnection();
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, vo.getTaskNameId());

			stmt.setString(2, vo.getToDate());
			stmt.setString(3, vo.getTaskDescription());
			stmt.setString(4, vo.getEstimatedTime());
			stmt.setString(5, vo.getTimeTaken());
			stmt.setString(6, vo.getRequestCompleted());
			stmt.setString(7, vo.getStatus());
			stmt.setString(8, vo.getUserId());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
