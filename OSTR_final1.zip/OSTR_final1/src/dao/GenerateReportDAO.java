package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import utils.DBUtils;
import utils.SQLQueries;
import vo.GenerateReportVO;
import vo.ReportVO;
import controller.GenerateReportController;
import exception.GenerateReportException;

public class GenerateReportDAO {
	String query = "";
	Connection con = null;

	public void fetchReport(GenerateReportVO vo)
			throws GenerateReportException, ClassNotFoundException,
			IOException, SQLException {
		// TODO Auto-generated method stub
		GenerateReportController.temp.clear();
		try {
			con = DBUtils.getConnection();
		} catch (SQLException e) {
			throw new GenerateReportException(e.getMessage());
		}

		query = SQLQueries.DATEBASEDREPORT;
		PreparedStatement stmt = con.prepareStatement(query);

		java.util.Date utilStartDate = vo.getFromDate();
		java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
		java.util.Date utilEndDate = vo.getToDate();
		java.sql.Date sqlEndDate = new java.sql.Date(utilEndDate.getTime());

		stmt.setDate(1, sqlStartDate);
		stmt.setDate(2, sqlEndDate);
		ResultSet set = stmt.executeQuery();
		// setValues(set);
		while (set.next()) {
			ReportVO vo1 = new ReportVO();

			vo1.setCompletionDate((set.getDate(1)));
			vo1.setEstimatedTime(set.getInt(2));
			vo1.setActualHours(set.getInt(3));
			vo1.setTaskId(set.getString(4));
			vo1.setTaskDescription(set.getString(5));
			vo1.setRequestsCompleted(set.getInt(6));
			vo1.setStatus(set.getString(7));
			vo1.setUserId(set.getLong(8));
			GenerateReportController.temp.add(vo1);
		}

	}

	public void fetchReportFromId(GenerateReportVO vo) throws SQLException {
		// TODO Auto-generated method stub
		GenerateReportController.temp.clear();
		try {
			con = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		query = SQLQueries.IDBASEDREPORT;
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setLong(1, vo.getAssociateId());
		ResultSet set = stmt.executeQuery();

		while (set.next()) {
			ReportVO vo1 = new ReportVO();
			// COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_NAME,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS,USERID
			vo1.setCompletionDate((set.getDate(1)));
			vo1.setEstimatedTime(set.getInt(2));
			vo1.setActualHours(set.getInt(3));
			vo1.setTaskId(set.getString(4));
			vo1.setTaskDescription(set.getString(5));
			vo1.setRequestsCompleted(set.getInt(6));
			vo1.setStatus(set.getString(7));
			vo1.setUserId(set.getLong(8));
			GenerateReportController.temp.add(vo1);
		}
	}

	public void fetchReportFromTaskId(GenerateReportVO vo) throws SQLException {
		// TODO Auto-generated method stub
		GenerateReportController.temp.clear();
		try {
			con = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		query = SQLQueries.TASKIDBASEDREPORT;
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, vo.getTaskId());
		ResultSet set = stmt.executeQuery();
		while (set.next()) {
			ReportVO vo1 = new ReportVO();
			// COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_NAME,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS,USERID
			vo1.setCompletionDate((set.getDate(1)));
			vo1.setEstimatedTime(set.getInt(2));
			vo1.setActualHours(set.getInt(3));
			vo1.setTaskId(set.getString(4));
			vo1.setTaskDescription(set.getString(5));
			vo1.setRequestsCompleted(set.getInt(6));
			vo1.setStatus(set.getString(7));
			vo1.setUserId(set.getLong(8));
			GenerateReportController.temp.add(vo1);

		}

	}

	public void fetchRecentReport() throws ClassNotFoundException, IOException,
			GenerateReportException, SQLException {
		try {
			con = DBUtils.getConnection();
		} catch (SQLException e) {
			throw new GenerateReportException(e.getMessage());
		}

		query = SQLQueries.GETRECENTREPORTS;
		PreparedStatement stmt = con.prepareStatement(query);
		ResultSet set = stmt.executeQuery();

		while (set.next()) {
			ReportVO vo1 = new ReportVO();
			// COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_NAME,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS,USERID
			vo1.setCompletionDate((set.getDate(1)));
			vo1.setEstimatedTime(set.getInt(2));
			vo1.setActualHours(set.getInt(3));
			vo1.setTaskId(set.getString(4));
			vo1.setTaskDescription(set.getString(5));
			vo1.setRequestsCompleted(set.getInt(6));
			vo1.setStatus(set.getString(7));
			vo1.setUserId(set.getLong(8));
			GenerateReportController.temp.add(vo1);
		}

	}

	public void fetchUserRecentReport(Long userId)
			throws ClassNotFoundException, IOException,
			GenerateReportException, SQLException {
		try {
			con = DBUtils.getConnection();
		} catch (SQLException e) {
			throw new GenerateReportException(e.getMessage());
		}

		query = SQLQueries.GETUSERRECENTREPORTS;
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setLong(1, userId);
		ResultSet set = stmt.executeQuery();
		while (set.next()) {
			ReportVO vo1 = new ReportVO();
			vo1.setCompletionDate((set.getDate(1)));
			vo1.setEstimatedTime(set.getInt(2));
			vo1.setActualHours(set.getInt(3));
			vo1.setTaskId(set.getString(4));
			vo1.setTaskDescription(set.getString(5));
			vo1.setRequestsCompleted(set.getInt(6));
			vo1.setStatus(set.getString(7));
			GenerateReportController.temp.add(vo1);
		}

	}

	public ArrayList<String> populateTask() throws GenerateReportException,
			ClassNotFoundException, IOException {
		ArrayList<String> tasks = new ArrayList<String>();
		String appender = "";
		try {
			con = DBUtils.getConnection();
			String query2 = "select task_name,task_id from task_list";
			PreparedStatement stmt1 = con.prepareStatement(query2);
			ResultSet set2 = stmt1.executeQuery(query2);
			while (set2.next()) {
				appender = set2.getString(1) + " - " + set2.getString(2);
				tasks.add(appender);
			}
		} catch (SQLException e) {
			throw new GenerateReportException(e.getMessage());
		}
		return tasks;

	}
}
