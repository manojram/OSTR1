package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import utils.DBUtils;
import utils.SQLQueries;
import vo.LoginVO;
import exception.LoginException;

public class LoginDAO {

	public String getPassword(LoginVO vo) throws LoginException,
			ClassNotFoundException, IOException {

		String pwd = "";
		int count = 0;
		String query = "";
		Connection con = null;
		try {
			con = DBUtils.getConnection();
			if (vo.getUserRole().equalsIgnoreCase("admin")) {
				query = SQLQueries.GETADMINPASSWORD;
			} else {
				query = SQLQueries.GETTEAMMEMBERPASSWORD;
			}
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, vo.getUserId());
			ResultSet set = stmt.executeQuery();
			while (set.next()) {
				count++;
				pwd = set.getString("password");
			}
			if (count == 0) {
				query = SQLQueries.CHECKMEMBERSTABLE;
				stmt = con.prepareStatement(query);
				stmt.setString(1, vo.getUserId());
				ResultSet set1 = stmt.executeQuery();
				if (set1.next()) {
					pwd = "1";
				}
			}
		} catch (SQLException e) {
			throw new LoginException(e.getMessage());
		}
		return pwd;
	}
}
