package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;

import utils.DBUtils;
import utils.SQLQueries;
import vo.LoginVO;
import exception.MemberRegistrationBusinessException;
import exception.MemberRegistrationException;

public class SessionTimeDAO {

	public Timestamp sessionlogin(LoginVO vo) throws ClassNotFoundException,
			IOException, MemberRegistrationException,
			MemberRegistrationBusinessException {
		Connection con = null;
		String query1 = SQLQueries.LASTLOGIN;
		String query = SQLQueries.SHOWLOGIN;
		String query2 = SQLQueries.UPDATELOGIN;
		Timestamp tt = null;
		try {
			con = DBUtils.getConnection();

			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, vo.getUserId());

			ResultSet set = stmt.executeQuery();

			while (set.next()) {
				System.out.println("DAO::");
				System.out.println(set.getString(1));
				tt = set.getTimestamp(2);
			}

			stmt = con.prepareStatement(query2);

			Calendar calendar = Calendar.getInstance();
			java.util.Date now = calendar.getTime();
			java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(
					now.getTime());

			stmt.setTimestamp(1, currentTimestamp);
			stmt.setString(2, vo.getUserId());

			stmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return tt;

	}
}
