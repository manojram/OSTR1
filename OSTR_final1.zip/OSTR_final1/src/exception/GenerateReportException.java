package exception;

public class GenerateReportException extends Exception {

	private static final long serialVersionUID = 1L;

	public GenerateReportException(String message) {
		super(message);
	}

	public GenerateReportException(Throwable cause) {
		super(cause);

	}

	public GenerateReportException(String message, Throwable cause) {
		super(message, cause);

	}
}
