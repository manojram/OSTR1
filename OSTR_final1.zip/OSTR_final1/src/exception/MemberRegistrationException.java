package exception;

public class MemberRegistrationException extends Exception{

	private static final long serialVersionUID = 1L;

	public MemberRegistrationException(String arg0) {
		super(arg0);

	}

	public MemberRegistrationException(Throwable arg0) {
		super(arg0);

	}

	public MemberRegistrationException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}
}
