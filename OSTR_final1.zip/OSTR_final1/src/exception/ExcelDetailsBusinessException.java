package exception;

public class ExcelDetailsBusinessException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExcelDetailsBusinessException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExcelDetailsBusinessException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ExcelDetailsBusinessException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ExcelDetailsBusinessException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
