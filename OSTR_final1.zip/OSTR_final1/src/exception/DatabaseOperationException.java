package exception;

public class DatabaseOperationException extends Exception {

}
