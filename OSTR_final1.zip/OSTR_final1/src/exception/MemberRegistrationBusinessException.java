package exception;

public class MemberRegistrationBusinessException extends Exception {
	private static final long serialVersionUID = 1L;

	public MemberRegistrationBusinessException(String message) {
		super(message);

	}

	public MemberRegistrationBusinessException(Throwable cause) {
		super(cause);

	}

	public MemberRegistrationBusinessException(String message, Throwable cause) {
		super(message, cause);

	}
}
