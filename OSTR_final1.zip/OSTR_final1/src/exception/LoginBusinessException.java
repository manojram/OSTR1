package exception;

public class LoginBusinessException extends Exception {
	private static final long serialVersionUID = 1L;

	public LoginBusinessException(String message) {
		super(message);

	}

	public LoginBusinessException(Throwable cause) {
		super(cause);

	}

	public LoginBusinessException(String message, Throwable cause) {
		super(message, cause);

	}

}
