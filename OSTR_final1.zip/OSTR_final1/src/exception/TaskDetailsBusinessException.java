package exception;

public class TaskDetailsBusinessException extends Exception {

	public TaskDetailsBusinessException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TaskDetailsBusinessException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TaskDetailsBusinessException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TaskDetailsBusinessException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
