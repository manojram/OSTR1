package vo;

public class TaskDetailsEntryVO {

	String toDate;
	String timeTaken;
	String taskNameId;
	String userId;

	String taskDescription;
	String requestCompleted;
	String estimatedTime;

	String status;

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getTaskNameId() {
		return taskNameId;
	}

	public void setTaskNameId(String task_name_id) {
		taskNameId = task_name_id;
	}

	public String getUserId() {
		return userId;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String task_Description) {
		this.taskDescription = task_Description;
	}

	public String getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(String timeTaken) {
		this.timeTaken = timeTaken;
	}

	public String getRequestCompleted() {
		return requestCompleted;
	}

	public void setRequestCompleted(String requestCompleted) {
		this.requestCompleted = requestCompleted;
	}

	public String getEstimatedTime() {
		return estimatedTime;
	}

	public void setEstimatedTime(String estimatedTime) {
		this.estimatedTime = estimatedTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
