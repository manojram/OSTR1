package utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * 
 * @author 322208 This class serves to create DB connections
 */

public class DBUtils {

	/** The connection. */
	private static Connection connection = null;

	/**
	 * Gets the connection.
	 * 
	 * @return the connection
	 * @throws ClassNotFoundException
	 *             the class not found exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws SQLException
	 *             the sQL exception
	 */
	public static Connection getConnection() throws ClassNotFoundException,
			IOException, SQLException {
		// if (connection == null){
		Connection connection = null;
		Properties prop = new Properties();
		InputStream inputStream = DBUtils.class.getClassLoader()
				.getResourceAsStream("resources/db.properties");
		prop.load(inputStream);
		String driver = prop.getProperty("driver");
		String url = prop.getProperty("url");
		String user = prop.getProperty("user");
		String password = prop.getProperty("password");
		Class.forName(driver);
		connection = DriverManager.getConnection(url, user, password);

		// }
		return connection;
	}

}
