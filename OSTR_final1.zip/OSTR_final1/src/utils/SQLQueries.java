package utils;

public class SQLQueries {

	public static final String GETADMINPASSWORD = "select password from admin_login where userid=?";
	public static final String GETTEAMMEMBERPASSWORD = "select password from TeamMember_login where userid=?";
	public static final String ADDTEAMMEMBER = "insert into teamMember_details values(?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String ADDTEAMMEMBERLOGIN = "insert into teamMember_login values(?,?)";
	public static final String UPDATETASKDETAILS = "insert into task_details values(?,?,?,?,?,?,?,?)";

	public static final String DATEBASEDREPORT = "select COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS,USERID from task_Details join task_list using(task_id) where COMPLETION_DATE between ? and ? ";
	public static final String IDBASEDREPORT = "select COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS,USERID from task_Details join task_list using(task_id) where userid=?";
	public static final String TASKIDBASEDREPORT = "select COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS,USERID from task_Details join task_list using(task_id) where task_id=?";

	public static final String VERIFYASSOCIATEID = "select userid from task_Details where userid=?";
	public static final String SETPASSWORD = "update teamMember_details set password=? where userid=?";
	public static final String SETLOGINPASSWORD = "update teamMember_login set password=? where userid=?";
	public static final String GETSECURITYQUESTION = "select security_question1,security_answer1,security_question2,security_answer2,security_question3,security_answer3 from teamMember_details where USERID=?";
	public static final String GETRECENTREPORTS = "select COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS,USERID from task_Details join task_list using(task_id)";
	public static final String GETUSERRECENTREPORTS = "select COMPLETION_DATE,ESTIMATED_TIME,TIME_TAKEN,TASK_ID,TASK_DESCRIPTION,REQUEST_COMPLETED,STATUS from task_Details join task_list using(task_id) where userid=?";
	public static final String GETUSERS = "select * from Members";

	public static final String ADDMEMBERDETAILS = "insert into members values(?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String GETUSERDETAILS = "select * from Members where userid=?";
	public static final String DELETEAPPROVEDUSERS = "delete from Members where userid=?";
	public static final String CHECKMEMBERSTABLE = "select userid from members where userid=?";

	public static final String LASTLOGIN = "insert into sessionlogin values (?,?)";
	public static final String SHOWLOGIN = "select userid,lastlogin from sessionlogin where userid=?";
	public static final String UPDATELOGIN = "update sessionlogin set lastlogin=? where userId=?;";
}
