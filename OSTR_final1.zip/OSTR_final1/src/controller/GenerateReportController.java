package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import property.PropertyUtil;
import vo.GenerateReportVO;
import vo.ReportVO;
import bo.GenerateReportBO;
import dao.GenerateReportDAO;
import exception.GenerateReportException;

/**
 * Servlet implementation class GenerateReportController
 */
public class GenerateReportController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger LOG = Logger
			.getLogger(GenerateReportController.class);
	public static ArrayList<ReportVO> temp = new ArrayList<ReportVO>();
	GenerateReportBO bo = new GenerateReportBO();
	GenerateReportDAO dao = new GenerateReportDAO();
	boolean flag;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		GenerateReportController.temp.clear();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		GenerateReportVO vo = new GenerateReportVO();
		HttpSession session = request.getSession();
		String user = session.getAttribute("User").toString();

		if (!(request.getParameter("fromDate") == null
				|| request.getParameter("fromDate") == "" || request
				.getParameter("fromDate").isEmpty())) {
			if (!(request.getParameter("toDate") == null
					|| request.getParameter("toDate") == "" || request
					.getParameter("toDate").isEmpty())) {
				try {
					vo.setFromDate(sdf.parse(request.getParameter("fromDate")));
					vo.setToDate(sdf.parse(request.getParameter("toDate")));
					Date start = new Date();
					Date end = new Date();
					start = vo.getFromDate();
					end = vo.getToDate();
					int compare = start.compareTo(end);
					Date today = new Date();
					if (start.before(today)) {
						flag = bo.validateDetails(vo);
						if (flag == true) {
							try {
								dao.fetchReport(vo);
								response.sendRedirect("DisplayReport.jsp");
							} catch (ClassNotFoundException e) {
								LOG.error("Exception" + e + new Date());

							} catch (GenerateReportException e) {
								LOG.error("Exception" + e + new Date());
								request.setAttribute("message", e.getMessage());
								RequestDispatcher dispatcher = request
										.getRequestDispatcher("ViewMyReports.jsp");
								dispatcher.forward(request, response);
								// TODO Auto-generated catch block

							} catch (SQLException e) {
								LOG.error("Exception" + e + new Date());
								e.printStackTrace();
							}
						} else {
							throw new GenerateReportException(
									PropertyUtil.getMessage("701"));
						}
					} else {
						throw new GenerateReportException(
								PropertyUtil.getMessage("702"));
					}
				} catch (GenerateReportException e) {
					// TODO Auto-generated catch block
					LOG.error("Exception" + e + new Date());
					request.setAttribute("message", e.getMessage());
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("ViewMyReports.jsp");
					dispatcher.forward(request, response);
				} catch (ParseException e) {
					LOG.error("Exception" + e + new Date());
					e.printStackTrace();
				}

			} else {
				request.setAttribute("message", "Select both dates");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("ViewMyReports.jsp");
				dispatcher.forward(request, response);
			}
		} else if (!(request.getParameter("associate_id") == null
				|| request.getParameter("associate_id") == "" || request
				.getParameter("associate_id").isEmpty())) {
			try {
				vo.setAssociateId(Long.parseLong(request
						.getParameter("associate_id")));
				flag = bo.validateAssociateId(vo);
				if (flag == true) {
					dao.fetchReportFromId(vo);
					response.sendRedirect("DisplayReport.jsp");
				} else {
					throw new GenerateReportException(
							PropertyUtil.getMessage("103"));

				}
			} catch (Exception e) {
				try {
					throw new GenerateReportException(
							PropertyUtil.getMessage("103"));
				} catch (GenerateReportException e1) {
					LOG.error("Exception" + e1 + new Date());
					request.setAttribute("message", e1.getMessage());
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("ViewMyReports.jsp");
					dispatcher.forward(request, response);
				}
			}

		} else if (!request.getParameter("taskNameID").equalsIgnoreCase(
				"select")) {
			String task = request.getParameter("taskNameID");
			String[] taskname = task.split(" ");
			vo.setTaskId(taskname[2]);
			try {
				dao.fetchReportFromTaskId(vo);
				response.sendRedirect("DisplayReport.jsp");
			} catch (SQLException e) {
				LOG.error("Exception" + e + new Date());
			}
		} else {
			request.setAttribute("message", "Select a value");
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("ViewMyReports.jsp");
			dispatcher.forward(request, response);
		}

	}
}
