package controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import vo.MemberRegistrationVO;
import bo.MemberRegistrationBO;
import dao.MemberRegistrationDAO;
import exception.MemberRegistrationBusinessException;
import exception.MemberRegistrationException;

public class MemberRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// private Logger logger = Logger.getLogger(this.getClass().getName());
		Logger logger = Logger.getLogger(this.getClass().getName());
		HttpSession sc = null;
		boolean flag = false;
		logger.info("Inside New Registration action.");
		MemberRegistrationVO memberVo = new MemberRegistrationVO();
		MemberRegistrationBO registrationBO = new MemberRegistrationBO();
		sc = request.getSession(true);
		memberVo.setUserId(request.getParameter("userId"));
		memberVo.setPassword(request.getParameter("password"));
		memberVo.setName(request.getParameter("name"));
		memberVo.setWorkLocation((request.getParameter("workLocation")));
		memberVo.setContactNumber(request.getParameter("contactNumber"));
		memberVo.setEmailId(request.getParameter("emailId"));
		memberVo.setSecurityQuestion1(request.getParameter("Securityquestion1"));
		memberVo.setSecurityAnswer1(request.getParameter("securityanswer1"));
		memberVo.setSecurityQuestion2(request.getParameter("Securityquestion2"));
		memberVo.setSecurityAnswer2(request.getParameter("securityanswer2"));
		memberVo.setSecurityQuestion3(request.getParameter("Securityquestion3"));
		memberVo.setSecurityAnswer3(request.getParameter("securityanswer3"));

		try {
			flag = registrationBO.validateMember(memberVo);
		} catch (MemberRegistrationBusinessException e) {
			logger.error("Exception" + e + new Date());
			request.setAttribute("message", e.getMessage());
		}
		if (flag == true) {
			try {

				MemberRegistrationDAO dao = new MemberRegistrationDAO();

				dao.addMemberDetails(memberVo);

			} catch (ClassNotFoundException e) {

				e.printStackTrace();
			} catch (MemberRegistrationException e) {

				logger.error("Exception" + e + new Date());
				request.setAttribute("message", e.getMessage());

			} catch (MemberRegistrationBusinessException e) {

				logger.error("Exception" + e + new Date());
				request.setAttribute("message", e.getMessage());

			}
			request.setAttribute("message",
					"you have Registered.Please wait for your approval!");
			final RequestDispatcher dispatcher = request
					.getRequestDispatcher("MemberRegistration.jsp");
			dispatcher.forward(request, response);
		} else {

			final RequestDispatcher dispatcher = request
					.getRequestDispatcher("MemberRegistration.jsp");
			dispatcher.forward(request, response);
		}

	}
}