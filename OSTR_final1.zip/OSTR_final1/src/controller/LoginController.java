package controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

import javax.security.auth.login.LoginException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import property.PropertyUtil;
import vo.LoginVO;
import bo.LoginBO;
import dao.SessionTimeDAO;
import exception.LoginBusinessException;
import exception.MemberRegistrationBusinessException;
import exception.MemberRegistrationException;

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger LOG = Logger.getLogger(LoginController.class);

	public static Timestamp time;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		LoginVO vo = new LoginVO();
		LoginBO bo = new LoginBO();
		String login = request.getParameter("b1");
		String user = request.getParameter("userId");

		boolean flag = false;
		LOG.info("Inside Login Controller");
		try {
			vo.setUserId(request.getParameter("userId"));
			vo.setPassword(request.getParameter("password"));
			vo.setUserRole(request.getParameter("Role"));
		} catch (Exception e) {
			LOG.error("Exception" + e + new Date());
			try {
				throw new LoginBusinessException(PropertyUtil.getMessage("501"));
			} catch (LoginBusinessException e1) {
				LOG.error("Exception" + e + new Date());
				e1.printStackTrace();
			}
		}

		SessionTimeDAO dao = new SessionTimeDAO();
		Timestamp t = null;
		try {
			t = dao.sessionlogin(vo);
			System.out.println("Timestamp: " + t);
			time = t;
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MemberRegistrationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MemberRegistrationBusinessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			flag = bo.validateUser(vo);
			if (flag == true) {
				HttpSession session = request.getSession(true);
				session.setAttribute("User", "admin");
				if (vo.getUserRole().equalsIgnoreCase("admin")) {
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("AdminHomePage.jsp");
					dispatcher.forward(request, response);
				} else {
					String userId = request.getParameter("userId");
					session.setAttribute("User", userId);

					RequestDispatcher dispatcher = request
							.getRequestDispatcher("TeamMemberHomePage.jsp");
					dispatcher.forward(request, response);
				}
			} else {
				throw new LoginBusinessException(PropertyUtil.getMessage("500"));
			}
		} catch (LoginException e) {
			LOG.error("Exception" + e + new Date());
			request.setAttribute("message", e.getMessage());
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("LoginScreen.jsp");
			dispatcher.forward(request, response);

		} catch (LoginBusinessException e) {
			LOG.error("Exception" + e + new Date());
			request.setAttribute("message", e.getMessage());
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("LoginScreen.jsp");
			dispatcher.forward(request, response);
		} catch (ClassNotFoundException e) {
			LOG.error("Exception" + e + new Date());
			e.printStackTrace();
		} catch (exception.LoginException e) {
			LOG.error("Exception" + e + new Date());
			e.printStackTrace();
		}

	}
}
