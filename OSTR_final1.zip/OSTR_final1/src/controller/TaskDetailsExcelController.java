package controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import property.PropertyUtil;
import exception.TaskDetailsBusinessException;

public class TaskDetailsExcelController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger LOG = Logger
			.getLogger(TaskDetailsExcelController.class);

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		LOG.info("Inside Task details  through Excel action.");
		try {
			ReadXLSheet xl = new ReadXLSheet();
			int res = xl.init(request.getParameter("file"));
			if (res == 0) {
				request.setAttribute("message", "Details updated Successfully");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("TaskDetailsEntry.jsp");
				dispatcher.forward(request, response);
			} else {
				request.setAttribute("message",
						"Excel file doesn't match the database");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("TaskDetailsEntry.jsp");
				dispatcher.forward(request, response);
			}
		} catch (Exception e) {
			try {
				throw new TaskDetailsBusinessException(
						PropertyUtil.getMessage("1103"));
			} catch (TaskDetailsBusinessException e1) {
				LOG.error("Exception" + e + new Date());
				request.setAttribute("message", e.getMessage());
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("TaskDetailsEntry.jsp");
				dispatcher.forward(request, response);

			}

		}
	}
}
