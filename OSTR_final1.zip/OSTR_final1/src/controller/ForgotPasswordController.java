package controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import bo.ForgotPasswordBO;
import dao.SetPasswordDAO;
import exception.MemberRegistrationBusinessException;

/**
 * Servlet implementation class ForgotPasswordController
 */
public class ForgotPasswordController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger LOG = Logger
			.getLogger(ForgotPasswordController.class);
	public static String userId;
	SetPasswordDAO dao = new SetPasswordDAO();

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		userId = request.getParameter("user_id");
		LOG.info("Inside Forgot Password Controller");
		ForgotPasswordBO bo = new ForgotPasswordBO();
		boolean flag = false;
		try {
			flag = bo.validateuser(userId);
		} catch (MemberRegistrationBusinessException e) {
			LOG.error("Exception" + e + new Date());
			e.printStackTrace();
		}
		if (flag == true) {
			try {
				dao.setPassword(userId);
				response.sendRedirect("SecurityCheck.jsp");
			} catch (MemberRegistrationBusinessException e1) {

				LOG.error("Exception" + e1 + new Date());
				request.setAttribute("message", e1.getMessage());
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("ForgotPassword.jsp");
				dispatcher.forward(request, response);
			}

		}

	}
}
