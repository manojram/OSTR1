package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import jxl.Cell;
import jxl.DateCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;
import property.PropertyUtil;
import exception.CompletiondateException;
import exception.ExcelDetailsBusinessException;
import exception.TaskDetailsBusinessException;

public class ReadXLSheet {
	int i = 0;

	public int init(String filePath) {

		FileInputStream fs = null;
		try {
			fs = new FileInputStream(new File(filePath));
			contentReading(fs);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				throw new TaskDetailsBusinessException(
						PropertyUtil.getMessage("1103"));
			} catch (TaskDetailsBusinessException e1) {
				i = 1;
			}
		} finally {
			try {
				fs.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return i;
	}

	public void getHeadingFromXlsFile(Sheet sheet) {
		int columnCount = sheet.getColumns();
		for (int i = 0; i < columnCount; i++) {

		}
	}

	public void contentReading(InputStream fileInputStream)
			throws SQLException, ClassNotFoundException,
			CompletiondateException, ExcelDetailsBusinessException,
			ParseException {
		WorkbookSettings ws = null;
		Workbook workbook = null;
		Sheet s = null;
		Cell rowData[] = null;
		int rowCount = '0';
		int columnCount = '0';
		DateCell dc = null;
		int totalSheet = 0;
		String query = "insert into task_details values(?,?,?,?,?,?,?,?)";
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/ostr_db",
							"root", "password-1");
			stmt = con.prepareStatement(query);

		} catch (SQLException e1) {

			e1.printStackTrace();
		}

		try {
			ws = new WorkbookSettings();
			ws.setLocale(new Locale("en", "EN"));
			workbook = Workbook.getWorkbook(fileInputStream, ws);

			totalSheet = workbook.getNumberOfSheets();
			if (totalSheet > 0) {

				for (int j = 0; j < totalSheet; j++) {

				}
			}

			s = workbook.getSheet(0);
			getHeadingFromXlsFile(s);
			rowCount = s.getRows();
			columnCount = s.getColumns();
			if (con != null) {
				for (int i = 1; i < rowCount; i++) {
					rowData = s.getRow(i);
					if (rowData[0].getContents().length() != 0) {

						for (int j = 0; j < columnCount; j++) {

							switch (j) {

							case 0:

								stmt.setString(1, rowData[j].getContents());
								break;
							case 1:

								SimpleDateFormat sdf = new SimpleDateFormat(
										"yyyy-MM-dd");
								Date d = sdf.parse(rowData[j].getContents());
								java.util.Date utilStartDate = d;
								java.sql.Date sqlStartDate = new java.sql.Date(
										utilStartDate.getTime());

								stmt.setDate(2, sqlStartDate);

								break;

							case 2:
								if (!(rowData[j].getContents() == ""
										|| rowData[j].getContents() == null || rowData[j]
										.getContents().equals(""))) {
									stmt.setString(3, rowData[j].getContents());
								} else
									throw new TaskDetailsBusinessException(
											PropertyUtil.getMessage("902"));
								break;

							case 3:
								if (!(rowData[j].getContents() == "")) {
									stmt.setInt(4, Integer.parseInt(rowData[j]
											.getContents()));
								} else
									throw new TaskDetailsBusinessException(
											PropertyUtil.getMessage("902"));
								break;

							case 4:

								int time = Integer.parseInt(rowData[j]
										.getContents());
								if (time < 20) {
									stmt.setInt(5, Integer.parseInt(rowData[j]
											.getContents()));
								} else {
									throw new ExcelDetailsBusinessException(
											PropertyUtil.getMessage("1102"));
								}
								break;

							case 5:
								if (!(rowData[j].getContents() == "")) {
									stmt.setInt(6, Integer.parseInt(rowData[j]
											.getContents()));
								} else {
									throw new ExcelDetailsBusinessException(
											PropertyUtil.getMessage("1102"));
								}
								break;
							case 6:

								stmt.setString(7, rowData[j].getContents());
								break;
							case 7:
								if (!(rowData[j].getContents() == "")) {
									stmt.setInt(8, Integer.parseInt(rowData[j]
											.getContents()));
								} else
									throw new ExcelDetailsBusinessException(
											PropertyUtil.getMessage("1102"));
								break;
							default:
								throw new ExcelDetailsBusinessException(
										PropertyUtil.getMessage("1105"));

							}

						}
						int y = stmt.executeUpdate();

						if (y <= 0) {

							throw new ExcelDetailsBusinessException(
									PropertyUtil.getMessage("1103"));
						}
					}

				}
				workbook.close();
			}
		} catch (IOException e) {

			e.printStackTrace();

		} catch (BiffException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				throw new TaskDetailsBusinessException(
						PropertyUtil.getMessage("1103"));
			} catch (TaskDetailsBusinessException e1) {
				i = 1;
			}

		}
	}
}
