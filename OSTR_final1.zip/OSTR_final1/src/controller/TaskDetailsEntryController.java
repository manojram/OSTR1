package controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import vo.TaskDetailsEntryVO;
import bo.TaskDetailsEntryBO;
import dao.TaskDetailsEntryDAO;
import exception.MemberRegistrationBusinessException;
import exception.MemberRegistrationException;
import exception.TaskDetailsBusinessException;

public class TaskDetailsEntryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger LOG = Logger
			.getLogger(TaskDetailsEntryController.class);

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession sc = null;
		boolean flag = false;
		LOG.info("Inside Task Details Entry Controller");
		TaskDetailsEntryVO taskVo = new TaskDetailsEntryVO();
		TaskDetailsEntryBO taskBo = new TaskDetailsEntryBO();
		sc = request.getSession(true);

		taskVo.setToDate(request.getParameter("toDate"));
		taskVo.setUserId(request.getParameter("userId"));
		taskVo.setTimeTaken(request.getParameter("timeTaken"));
		taskVo.setTaskNameId(request.getParameter("taskNameID"));
		taskVo.setTaskDescription(request.getParameter("taskDescription"));
		taskVo.setStatus(request.getParameter("status"));
		taskVo.setRequestCompleted(request.getParameter("requestsCompleted"));

		taskVo.setEstimatedTime(request.getParameter("estimatedtime"));

		try {
			flag = taskBo.validateTask(taskVo);
		} catch (TaskDetailsBusinessException e) {
			LOG.error("Exception" + e + new Date());
			request.setAttribute("message", e.getMessage());

		} catch (MemberRegistrationBusinessException e) {
			LOG.error("Exception" + e + new Date());
			request.setAttribute("message", e.getMessage());
		} catch (ParseException e) {

		}
		if (flag == true) {
			try {
				TaskDetailsEntryDAO dao = new TaskDetailsEntryDAO();
				dao.updateTaskDetails(taskVo);
			} catch (ClassNotFoundException e) {
				request.setAttribute("message", e.getMessage());
				LOG.error("Exception" + e + new Date());
			} catch (MemberRegistrationException e) {
				LOG.error("Exception" + e + new Date());
				request.setAttribute("message", e.getMessage());

				e.printStackTrace();
			} catch (TaskDetailsBusinessException e) {
				LOG.error("Exception" + e + new Date());
				request.setAttribute("message", e.getMessage());

			}
			request.setAttribute("message", "Task Details Updated");
			sc.setAttribute("status", "success");

			final RequestDispatcher dispatcher = request
					.getRequestDispatcher("TaskDetailsEntry.jsp");
			dispatcher.forward(request, response);
		} else {
			final RequestDispatcher dispatcher = request
					.getRequestDispatcher("TaskDetailsEntry.jsp");
			dispatcher.forward(request, response);
		}

	}
}
