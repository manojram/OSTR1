package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import dao.ApproveUsersDAO;
import exception.MemberRegistrationBusinessException;
import exception.MemberRegistrationException;

/**
 * Servlet implementation class ApproveMembersController
 */
public class ApproveMembersController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger LOG = Logger
			.getLogger(ApproveMembersController.class);

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if (request.getParameterValues("select") == null) {
			request.setAttribute("message", "No Ids were selected for approval");
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("ApproveMembers.jsp");
			dispatcher.forward(request, response);
		} else {
			String val[] = request.getParameterValues("select");

			ApproveUsersDAO dao = new ApproveUsersDAO();
			LOG.info("Inside Approve Members controller.");
			try {
				dao.getUsers(val);
				request.setAttribute("message", "The ID's are Approved");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("ApproveMembers.jsp");
				dispatcher.forward(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				LOG.error("Exception" + e + new Date());
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				LOG.error("Exception" + e + new Date());
				e.printStackTrace();

			} catch (MemberRegistrationException e) {
				// TODO Auto-generated catch block
				LOG.error("Exception" + e + new Date());
				e.printStackTrace();

			} catch (MemberRegistrationBusinessException e) {
				LOG.error("Exception" + e + new Date());
				e.printStackTrace();
			}
		}
	}
}
