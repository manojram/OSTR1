package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import bo.ForgotPasswordBO;

public class SecurityCheckController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger LOG = Logger
			.getLogger(SecurityCheckController.class);

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		LOG.info("Inside Security Check Controller.");
		String securityAnswer1 = request.getParameter("answer1");
		String securityAnswer2 = request.getParameter("answer2");
		String securityAnswer3 = request.getParameter("answer3");
		if (securityAnswer1.equalsIgnoreCase(ForgotPasswordBO.vo.getAnswer1())
				&& securityAnswer2.equalsIgnoreCase(ForgotPasswordBO.vo
						.getAnswer2())
				&& securityAnswer3.equalsIgnoreCase(ForgotPasswordBO.vo
						.getAnswer3())) {
			response.sendRedirect("NewPassword.jsp");
		} else {

			request.setAttribute("message", "Incorrect Answer");
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("SecurityCheck.jsp");
			dispatcher.forward(request, response);
		}
	}
}
