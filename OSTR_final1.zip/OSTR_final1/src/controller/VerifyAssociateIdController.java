package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import property.PropertyUtil;
import vo.GenerateReportVO;
import vo.ReportVO;
import bo.GenerateReportBO;
import dao.DatabaseChartDAO;
import dao.GenerateReportDAO;
import exception.GenerateReportException;

/**
 * Servlet implementation class GenerateReportController
 */
public class VerifyAssociateIdController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger LOG = Logger
			.getLogger(VerifyAssociateIdController.class);

	/**
	 * Default constructor.
	 */
	public static ArrayList<ReportVO> temp = new ArrayList<ReportVO>();
	GenerateReportBO bo = new GenerateReportBO();
	GenerateReportDAO dao = new GenerateReportDAO();
	boolean flag;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		LOG.info("Inside Verify Associate Id controller");
		GenerateReportVO vo = new GenerateReportVO();
		if (!(request.getParameter("ID") == null
				|| request.getParameter("ID") == "" || request.getParameter(
				"ID").isEmpty())) {
			try {
				vo.setAssociateId(Long.parseLong(request.getParameter("ID")));
				flag = bo.validateAssociateId(vo);
				if (flag == true) {
					try {
						DatabaseChartDAO dao = new DatabaseChartDAO();
						flag = dao.verifyId(vo);
						if (flag == true) {
							RequestDispatcher disp = request
									.getRequestDispatcher("/DatabaseChartAssociateId");
							disp.forward(request, response);
						} else {
							throw new GenerateReportException(
									PropertyUtil.getMessage("504"));
						}
					} catch (GenerateReportException e) {
						LOG.error("Exception" + e + new Date());
						request.setAttribute("message", e.getMessage());
						RequestDispatcher dispatcher = request
								.getRequestDispatcher("ViewGraphDetails.jsp");
						dispatcher.forward(request, response);
					} catch (ClassNotFoundException e) {
						LOG.error("Exception" + e + new Date());
					} catch (SQLException e) {
						LOG.error("Exception" + e + new Date());
					} catch (InstantiationException e) {
						LOG.error("Exception" + e + new Date());
					} catch (IllegalAccessException e) {
						LOG.error("Exception" + e + new Date());
					}
				} else {
					throw new GenerateReportException(
							PropertyUtil.getMessage("502"));
				}
			} catch (GenerateReportException e) {
				LOG.error("Exception" + e + new Date());
				request.setAttribute("message", e.getMessage());
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("ViewGraphDetails.jsp");
				dispatcher.forward(request, response);
			} catch (Exception e) {
				try {
					throw new GenerateReportException(
							PropertyUtil.getMessage("103"));
				} catch (GenerateReportException e1) {
					LOG.error("Exception" + e1 + new Date());
					request.setAttribute("message", e1.getMessage());
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("ViewGraphDetails.jsp");
					dispatcher.forward(request, response);
				}
			}
		} else {
			request.setAttribute("message", "Associate ID not Entered");
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("ViewGraphDetails.jsp");
			dispatcher.forward(request, response);
		}
	}
}