package bo;

import java.io.IOException;

import property.PropertyUtil;
import vo.LoginVO;
import dao.LoginDAO;
import exception.LoginBusinessException;
import exception.LoginException;

public class LoginBO {

	public boolean validateUser(LoginVO vo) throws LoginBusinessException,
			LoginException, javax.security.auth.login.LoginException,
			ClassNotFoundException, IOException {
		boolean flag = false;
		String pwd = "";
		if (vo.getUserId() == "" || vo.getPassword() == "") {
			throw new LoginBusinessException(PropertyUtil.getMessage("500"));
		} else {
			LoginDAO dao = new LoginDAO();

			pwd = dao.getPassword(vo);
			if (pwd.equals(vo.getPassword())) {
				flag = true;
			} else if (pwd.equalsIgnoreCase("1")) {
				throw new LoginBusinessException(PropertyUtil.getMessage("511"));
			} else if (pwd.equalsIgnoreCase("")) {
				throw new LoginBusinessException(PropertyUtil.getMessage("510"));
			} else {
				throw new LoginBusinessException(PropertyUtil.getMessage("500"));
			}

		}
		return flag;
	}
}
