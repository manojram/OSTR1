package bo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import property.PropertyUtil;
import vo.TaskDetailsEntryVO;
import exception.MemberRegistrationBusinessException;
import exception.TaskDetailsBusinessException;

public class TaskDetailsEntryBO {
	boolean flag = false;

	public boolean validateTask(TaskDetailsEntryVO taskVo)
			throws MemberRegistrationBusinessException,
			TaskDetailsBusinessException, ParseException {
		String compdate = taskVo.getToDate();
		String estimatedTimeTaken = taskVo.getEstimatedTime();
		String timeTaken = taskVo.getTimeTaken();
		String id = taskVo.getUserId();
		String Request = taskVo.getRequestCompleted();
		String Taskdes = taskVo.getTaskDescription();

		if (compdate == "") {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("800"));
		}

		if (estimatedTimeTaken == "" || estimatedTimeTaken == null) {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("800"));
		}

		if (timeTaken == "" || timeTaken == null) {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("800"));
		}

		if (id == "") {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("800"));
		}

		if (Request == "") {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("800"));
		}

		if (Taskdes == "") {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("800"));
		}

		else
			flag = true;

		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date d1 = sdf.parse(compdate);

		if (d1.before(d)) {
			flag = true;
		} else {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("801"));
		}

		if (Integer.parseInt(taskVo.getEstimatedTime()) < 24) {
			flag = true;
		} else {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("802"));
		}

		if (Integer.parseInt(taskVo.getTimeTaken()) < 24) {
			flag = true;
		} else {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("803"));
		}

		if (Integer.parseInt(taskVo.getRequestCompleted()) > 0) {
			flag = true;
		} else {
			flag = false;
			throw new TaskDetailsBusinessException(
					PropertyUtil.getMessage("804"));
		}

		if (flag == true) {
			if (flag == true) {
				if (!(id.length() == 6)) {
					flag = false;
					throw new TaskDetailsBusinessException(
							PropertyUtil.getMessage("805"));
				} else {
					flag = true;
				}
			}
		}

		return flag;
	}
}
