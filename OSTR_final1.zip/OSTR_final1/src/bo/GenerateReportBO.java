package bo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;

import org.joda.time.DateTime;
import org.joda.time.Days;

import property.PropertyUtil;
import vo.GenerateReportVO;
import vo.ReportVO;
import dao.GenerateReportDAO;
import exception.GenerateReportException;

public class GenerateReportBO {
	boolean flag = false;
	GenerateReportDAO dao = new GenerateReportDAO();
	public static long userId;

	public static ArrayList<ReportVO> tempList = new ArrayList<ReportVO>();

	public boolean validateDetails(GenerateReportVO vo)
			throws GenerateReportException, ServletException, IOException {
		// TODO Auto-generated method stub
		Date start = new Date();
		Date end = new Date();
		start = vo.getFromDate();
		end = vo.getToDate();
		int compare = start.compareTo(end);
		Date today = new Date();
		if (start.before(today)) {
			flag = true;

			if (compare <= 0) {
				flag = true;
				// if (start.getYear() == end.getYear()
				// && start.getMonth() == end.getMonth()
				// && end.getDate() - start.getDate() <= 7) {
				// flag = true;
				// } else {
				// flag = false;
				// }
				int days_diff = Days.daysBetween(new DateTime(start),
						new DateTime(end)).getDays();
				if (days_diff <= 30) {
					flag = true;
				} else {
					flag = false;
				}
				// if (start.getYear() - end.getYear() <= 1) {
				// if (Math.abs(start.getMonth() - end.getMonth()) == 1) {
				// if (Math.abs(start.getDate() - end.getDate()) < 30) {
				// flag = true;
				// } else {
				// flag = false;
				// }
				// } else if (start.getMonth() == end.getMonth()) {
				// flag = true;
				// } else {
				// flag = false;
				// }
				//
				// } else {
				// flag = false;
				// }
			} else {
				flag = false;
				throw new GenerateReportException(
						PropertyUtil.getMessage("101"));
			}

		} else {
			throw new GenerateReportException(PropertyUtil.getMessage("102"));
		}
		return flag;
	}

	public boolean validateAssociateId(GenerateReportVO vo)
			throws GenerateReportException {
		// TODO Auto-generated method stub
		String id;
		id = "" + vo.getAssociateId();
		if (!(id.length() == 6)) {
			flag = false;
			throw new GenerateReportException(PropertyUtil.getMessage("103"));
		} else {
			flag = true;
		}
		return flag;
	}

}
