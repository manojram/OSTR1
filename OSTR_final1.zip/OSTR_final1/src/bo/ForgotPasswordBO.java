package bo;

import property.PropertyUtil;
import vo.ForgotPasswordVO;
import dao.SetPasswordDAO;
import exception.MemberRegistrationBusinessException;

public class ForgotPasswordBO {
	boolean flag = false;

	public static ForgotPasswordVO vo = new ForgotPasswordVO();

	public boolean validateuser(String userId)
			throws MemberRegistrationBusinessException {

		String id = userId;
		if (id == "" || id == null) {
			flag = false;
			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("502"));
		} else {
			if (!(id.length() == 6)) {
				flag = false;
				throw new MemberRegistrationBusinessException(
						PropertyUtil.getMessage("502"));
			} else {
				flag = true;
			}
		}

		return flag;
	}

	SetPasswordDAO dao = new SetPasswordDAO();

}
