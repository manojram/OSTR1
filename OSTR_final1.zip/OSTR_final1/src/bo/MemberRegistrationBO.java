package bo;

import java.util.regex.Pattern;

import property.PropertyUtil;
import vo.MemberRegistrationVO;
import exception.MemberRegistrationBusinessException;

public class MemberRegistrationBO {
	boolean flag = false;

	public boolean validateMember(MemberRegistrationVO memberVo)
			throws MemberRegistrationBusinessException {
		String fname = memberVo.getName();
		String id = memberVo.getUserId();
		String email = memberVo.getEmailId();
		String contact = memberVo.getContactNumber();
		String sec1 = memberVo.getSecurityAnswer1();
		String sec2 = memberVo.getSecurityAnswer2();
		String sec3 = memberVo.getSecurityAnswer3();
		String pwd = memberVo.getPassword();
		char[] tmp = fname.toCharArray();

		if (id == "" || id.equals("") || id == null) {
			flag = false;
			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("600"));
		}

		if (pwd == "") {
			flag = false;

			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("601"));

		}

		if (fname == "") {
			flag = false;

			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("602"));

		}

		if (contact == "") {
			flag = false;

			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("603"));
		}

		if (email == "") {
			flag = false;

			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("604"));
		}

		if (sec1 == "") {
			flag = false;

			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("605"));
		}
		if (sec2 == "") {
			flag = false;

			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("605"));
		}
		if (sec3 == "") {
			flag = false;

			throw new MemberRegistrationBusinessException(
					PropertyUtil.getMessage("605"));
		}

		else
			flag = true;

		if (flag == true) {

			if (flag == true) {
				if (!(id.length() == 6)) {
					flag = false;
					throw new MemberRegistrationBusinessException(
							PropertyUtil.getMessage("606"));
				} else {
					flag = true;
				}
			}
		}

		if (flag == true) {
			for (int i = 0; i < tmp.length; i++) {
				if (!Character.isLetter(tmp[i])) {
					flag = false;
					throw new MemberRegistrationBusinessException(
							PropertyUtil.getMessage("607"));

				}
			}

		}

		if (flag == true) {

			if (contact.length() != 10) {
				flag = false;
				throw new MemberRegistrationBusinessException(
						PropertyUtil.getMessage("608"));
			} else {
				flag = true;
			}
		}

		if (flag == true) {
			if (!Pattern
					.matches(
							"^[a-z0-9_.]+[@]([a-z0-9]+)[.](([a-z]{2}[.][a-z]{2})+|([a-z]{3})+)$",
							email)) {
				flag = false;
				throw new MemberRegistrationBusinessException(
						PropertyUtil.getMessage("609"));
			}
		}

		return flag;
	}
}