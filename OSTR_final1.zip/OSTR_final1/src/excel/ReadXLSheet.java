package excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Locale;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;

public class ReadXLSheet {
	public ReadXLSheet() {

	}

	public static void init(String filePath) {
		FileInputStream fs = null;
		try {
			fs = new FileInputStream(new File(filePath));
			contentReading(fs);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fs.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// Returns the Headings used inside the excel sheet
	public static void getHeadingFromXlsFile(Sheet sheet) {
		int columnCount = sheet.getColumns();
		for (int i = 0; i < columnCount; i++) {

		}
	}

	public static void contentReading(InputStream fileInputStream)
			throws SQLException {
		WorkbookSettings ws = null;
		Workbook workbook = null;
		Sheet s = null;
		Cell rowData[] = null;
		int rowCount = '0';
		int columnCount = '0';
		// DateCell dc = null;
		int totalSheet = 0;

		String query = "insert into employee values(?,?,?)";
		Connection con = null;
		try {
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "password-1");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			ws = new WorkbookSettings();
			ws.setLocale(new Locale("en", "EN"));
			workbook = Workbook.getWorkbook(fileInputStream, ws);

			totalSheet = workbook.getNumberOfSheets();
			if (totalSheet > 0) {

				for (int j = 0; j < totalSheet; j++) {
				}
			}

			// Getting Default Sheet i.e. 0
			s = workbook.getSheet(0);

			// Reading Individual Cell
			getHeadingFromXlsFile(s);

			// Total Total No Of Rows in Sheet, will return you no of rows that
			// are occupied with some data

			rowCount = s.getRows();

			// Total Total No Of Columns in Sheet

			columnCount = s.getColumns();

			// Reading Individual Row Content
			for (int i = 0; i < rowCount; i++) {
				// Get Individual Row
				PreparedStatement stmt = con.prepareStatement(query);
				rowData = s.getRow(i);
				if (rowData[0].getContents().length() != 0) {

					// the first date column must not null

					for (int j = 0; j < columnCount; j++) {

						switch (j) {
						case 0:

							stmt.setInt(1,
									Integer.parseInt(rowData[j].getContents()));
							break;
						case 1:

							stmt.setString(2, rowData[j].getContents());
							break;
						case 2:

							stmt.setString(3, rowData[j].getContents());
						default:
							break;
						}
					}

				}
				stmt.executeUpdate();
			}
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();

		} catch (BiffException e) {
			e.printStackTrace();
		}
	}
}