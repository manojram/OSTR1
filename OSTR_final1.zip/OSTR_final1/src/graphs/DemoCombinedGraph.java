package graphs;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.AbstractCategoryItemLabelGenerator;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.CombinedDomainCategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

/**
 * A demo for the {@link CombinedDomainCategoryPlot} class.
 */
public class DemoCombinedGraph extends ApplicationFrame {
	Connection connection = null;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static Paint paint = null;
	final static LineAndShapeRenderer renderer1 = new LineAndShapeRenderer();

	/**
	 * Creates a new demo instance.
	 * 
	 * @param title
	 *            the frame title.
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	public DemoCombinedGraph(final String title) throws InstantiationException,
			IllegalAccessException, ClassNotFoundException {

		super(title);

		// add the chart to a panel...
		final ChartPanel chartPanel = new ChartPanel(createChart());
		chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
		setContentPane(chartPanel);

	}

	/**
	 * Creates a dataset.
	 * 
	 * @return A dataset.
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	public CategoryDataset createDataset1() throws InstantiationException,
			IllegalAccessException, ClassNotFoundException {

		final DefaultCategoryDataset result = new DefaultCategoryDataset();

		// row keys...
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		String query = "Select task_id,sum(time_taken) from task_details join task_list using(task_id) group by task_id";
		try {
			connection = DriverManager
					.getConnection("jdbc:mysql://127.0.0.1:3306/ostr_db",
							"root", "password-1");
		} catch (SQLException e) {
			System.out.println("no connection");
			e.printStackTrace();
		}
		try {
			PreparedStatement stmt = connection.prepareStatement(query);
			ResultSet set = stmt.executeQuery();
			final String series1 = "Time Taken";
			final String series2 = "Estimated Time";
			while (set.next()) {
				String type1 = set.getString(1);
				result.addValue(set.getLong(2), series1, type1);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		String query1 = "Select task_id,sum(estimated_time) from task_details join task_list using(task_id) group by task_id";
		try {
			PreparedStatement stmt = connection.prepareStatement(query1);
			ResultSet set = stmt.executeQuery();
			final String series1 = "Time Taken";
			final String series2 = "Estimated Time";
			while (set.next()) {
				String type1 = set.getString(1);
				result.addValue(set.getLong(2), series2, type1);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		String query3 = "Select task_id,sum(estimated_time-time_taken)as DEVIATION from task_details join task_list using(task_id) group by task_id";
		try {
			PreparedStatement stmt = connection.prepareStatement(query3);
			ResultSet set = stmt.executeQuery();
			final String series3 = "Deviation";
			while (set.next()) {
				String type1 = set.getString(1);
				result.addValue(set.getLong(2), series3, type1);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		return result;

	}

	/**
	 * Creates a dataset.
	 * 
	 * @return A dataset.
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	public CategoryDataset createDataset2() throws InstantiationException,
			IllegalAccessException, ClassNotFoundException {

		final DefaultCategoryDataset result = new DefaultCategoryDataset();
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		String query = "Select count(userid),task_id from task_details join task_list using(task_id) where time_taken<=estimated_time group by task_id";
		try {
			connection = DriverManager
					.getConnection("jdbc:mysql://127.0.0.1:3306/ostr_db",
							"root", "password-1");
		} catch (SQLException e) {
			System.out.println("no connection");
			e.printStackTrace();
		}
		try {
			PreparedStatement stmt = connection.prepareStatement(query);
			ResultSet set = stmt.executeQuery();
			final String series3 = "Completed Users";
			final String series4 = "Incomplete";
			while (set.next()) {
				String type1 = set.getString(2);
				result.addValue(set.getInt(1), series3, type1);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		String query1 = "Select count(userid),task_id from task_details join task_list using(task_id) where time_taken>estimated_time group by task_id";
		try {
			PreparedStatement stmt = connection.prepareStatement(query1);
			ResultSet set = stmt.executeQuery();
			final String series3 = "Completed Users";
			final String series4 = "Incomplete";
			while (set.next()) {
				String type1 = set.getString(2);
				result.addValue(set.getInt(1), series4, type1);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		return result;

	}

	private JFreeChart createChart() throws InstantiationException,
			IllegalAccessException, ClassNotFoundException {

		final CategoryDataset dataset1 = createDataset1();
		final NumberAxis rangeAxis1 = new NumberAxis("Total Hours");
		rangeAxis1.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		final LineAndShapeRenderer renderer1 = new LineAndShapeRenderer();
		renderer1
				.setBaseToolTipGenerator(new StandardCategoryToolTipGenerator());
		renderer1.setBaseItemLabelGenerator(new CustomLabelGenerator());
		renderer1.setBaseItemLabelsVisible(true);
		renderer1.setSeriesStroke(0, new BasicStroke(2.0f,
				BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
				new float[] { 10.0f, 6.0f }, 0.0f));
		renderer1.setShapesVisible(true);
		renderer1.setDrawOutlines(true);
		renderer1.setUseFillPaint(true);
		final CategoryPlot subplot1 = new CategoryPlot(dataset1, null,
				rangeAxis1, renderer1);
		subplot1.setDomainGridlinesVisible(true);
		final CategoryDataset dataset2 = createDataset2();
		final NumberAxis rangeAxis2 = new NumberAxis("No Of Members");
		rangeAxis2.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		final BarRenderer renderer2 = new BarRenderer();
		renderer2
				.setBaseToolTipGenerator(new StandardCategoryToolTipGenerator());
		renderer2.setBaseItemLabelGenerator(new CustomLabelGenerator());
		renderer2.setBaseItemLabelPaint(Color.black);
		renderer2.setBaseItemLabelsVisible(true);
		renderer2.setSeriesStroke(0, new BasicStroke(2.0f,
				BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
				new float[] { 10.0f, 6.0f }, 0.0f));
		final CategoryPlot subplot2 = new CategoryPlot(dataset2, null,
				rangeAxis2, renderer2);
		subplot2.setDomainGridlinesVisible(true);
		final CategoryAxis domainAxis = new CategoryAxis("Tasks");
		final CombinedDomainCategoryPlot plot = new CombinedDomainCategoryPlot(
				domainAxis);
		plot.add(subplot1, 2);
		plot.add(subplot2, 1);

		final JFreeChart result = new JFreeChart(
				"Combined Chart of Task Details", new Font("SansSerif",
						Font.BOLD, 12), plot, true);
		// result.getLegend().setAnchor(Legend.SOUTH);
		return result;

	}

	public static void main(final String[] args) throws InstantiationException,
			IllegalAccessException, ClassNotFoundException {

		final String title = "Combined Chart of Task Details";
		final DemoCombinedGraph demo = new DemoCombinedGraph(title);
		demo.pack();
		RefineryUtilities.centerFrameOnScreen(demo);
		demo.setVisible(true);

	}

	static class CustomLabelGenerator extends
			AbstractCategoryItemLabelGenerator implements
			CategoryItemLabelGenerator {

		private static final long serialVersionUID = 1L;

		public CustomLabelGenerator() {
			super("", NumberFormat.getInstance());

		}

		public String generateLabel(CategoryDataset dataset, int series,
				int category) {

			String result = null;
			Number value = dataset.getValue(series, category);
			result = value.toString();
			int val = value.intValue();
			if (val < 0) {
				paint = Color.red;
				renderer1.setBaseItemLabelPaint(paint);
			} else {
				paint = Color.black;
				renderer1.setBaseItemLabelPaint(paint);
			}
			return result;
		}

		public String generateRowLabel(CategoryDataset arg0, int arg1) {
			return null;
		}

		public String generateColumnLabel(CategoryDataset arg0, int arg1) {

			return null;
		}
	}

}
