package graphs;

import java.awt.BasicStroke;
import java.awt.Color;
import java.io.IOException;
import java.text.NumberFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.AbstractCategoryItemLabelGenerator;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.jdbc.JDBCCategoryDataset;

import dao.DatabaseChartDAO;

public class DatabaseChartTaskID extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static JFreeChart chart;

	@SuppressWarnings("deprecation")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		JDBCCategoryDataset dataset = null;
		try {
			DatabaseChartDAO dao = new DatabaseChartDAO();
			dataset = dao.generateGraphTask();
			final PlotOrientation HORIZONTAL = PlotOrientation.VERTICAL;
			chart = ChartFactory.createLineChart("Task-Time Graph", "tasks",
					"hours", dataset, HORIZONTAL, true, true, false);
			CategoryPlot plot = chart.getCategoryPlot();

			LineAndShapeRenderer lrenderer = (LineAndShapeRenderer) plot
					.getRenderer();
			lrenderer.setSeriesStroke(0, new BasicStroke(2.0f,
					BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
					new float[] { 10.0f, 6.0f }, 0.0f));
			lrenderer.setShapesVisible(true);
			lrenderer.setDrawOutlines(true);
			lrenderer.setUseFillPaint(true);
			lrenderer.setFillPaint(Color.BLACK);
			lrenderer.setBaseItemLabelGenerator(new CustomLabelGenerator());
			lrenderer.setBaseItemLabelsVisible(true);
			response.sendRedirect("ViewTaskGraph.jsp");

		} catch (InstantiationException e) {

			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static class CustomLabelGenerator extends
			AbstractCategoryItemLabelGenerator implements
			CategoryItemLabelGenerator {

		private static final long serialVersionUID = 1L;

		public CustomLabelGenerator() {
			super("", NumberFormat.getInstance());

		}

		public String generateLabel(CategoryDataset dataset, int series,
				int category) {

			String result = null;
			Number value = dataset.getValue(series, category);
			result = value.toString();
			int val = value.intValue();
			return result;
		}

		public String generateRowLabel(CategoryDataset arg0, int arg1) {
			return null;
		}

		public String generateColumnLabel(CategoryDataset arg0, int arg1) {

			return null;
		}
	}

}
